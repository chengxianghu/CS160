package com.chengxianghu.prg01;

import android.app.Activity;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;


import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class PRG01Activity extends Activity {
    public final static String EXTRA_MESSAGE = "com.mycompany.prg01.MESSAGE";
    public HashMap<String, String> engToSpaMap;
    public HashMap<String, String> engToMadMap;
    public HashMap<String, String> spaToEngMap;
    public HashMap<String, String> spaToMadMap;
    public HashMap<String, String> madToEngMap;
    public HashMap<String, String> madToSpaMap;
    public HashSet<String> engWordMap;
    public HashSet<String> spaWordMap;
    public HashSet<String> madWordMap;
    public Spinner fromSpinner;
    public Spinner toSpinner;
    public Spinner wordSpinner;
    public Spinner chineseSpinner;
    public Spinner spanishSpinner;
    public Spinner englishSpinner;
    public boolean allToggle;
    public boolean show;

    public PRG01Activity() {
        allToggle = true;
        show = true;
        engToMadMap = new HashMap<String, String>();
        engToSpaMap = new HashMap<String, String>();
        spaToEngMap = new HashMap<String, String>();
        spaToMadMap = new HashMap<String, String>();
        madToEngMap = new HashMap<String, String>();
        madToSpaMap = new HashMap<String, String>();
        engWordMap = new HashSet<String>();
        spaWordMap = new HashSet<String>();
        madWordMap = new HashSet<String>();

        engToSpaMap.put("hello", "hola");
        engToSpaMap.put("how much?", "Cuánto?");
        engToSpaMap.put("please", "por favor");
        engToSpaMap.put("goodbye", "adiós");
        engToSpaMap.put("thank you", "gracias");

        spaToEngMap.put("hola", "hello");
        spaToEngMap.put("Cuánto?", "how much?");
        spaToEngMap.put("por favor", "please");
        spaToEngMap.put("adiós", "goodbye");
        spaToEngMap.put("gracias", "thank you");

        engToMadMap.put("hello", "你好");
        engToMadMap.put("how much?", "多少钱?");
        engToMadMap.put("please", "请");
        engToMadMap.put("goodbye", "再见");
        engToMadMap.put("thank you", "谢谢");

        madToEngMap.put("你好", "hello");
        madToEngMap.put("多少钱?", "how much?");
        madToEngMap.put("请", "please");
        madToEngMap.put("再见", "goodbye");
        madToEngMap.put("谢谢", "thank you");

        madToSpaMap.put("你好", "hola");
        madToSpaMap.put("再见", "adiós");
        madToSpaMap.put("多少钱?", "Cuánto?");
        madToSpaMap.put("谢谢", "gracias");
        madToSpaMap.put("请", "gracias");

        spaToMadMap.put("hola", "你好");
        spaToMadMap.put("adiós", "再见");
        spaToMadMap.put("Cuánto?", "多少钱?");
        spaToMadMap.put("gracias", "谢谢");
        spaToMadMap.put("por favor", "请");

        engWordMap.add("hello");
        engWordMap.add("thank you");
        engWordMap.add("how much?");
        engWordMap.add("please");
        engWordMap.add("goodbye");

        spaWordMap.add("hola");
        spaWordMap.add("adiós");
        spaWordMap.add("Cuánto?");
        spaWordMap.add("gracias");
        spaWordMap.add("por favor");

        madWordMap.add("你好");
        madWordMap.add("再见");
        madWordMap.add("多少钱?");
        madWordMap.add("谢谢");
        madWordMap.add("请");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prg01);

        chooseCategory();
        chooseEnglish();
        chooseSpanish();
        chooseChinese();
        chooseTo();
        chooseWord();

        Button btn = (Button) findViewById(R.id.all_button);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!allToggle) {
                    displayAll();
                    allToggle = true;
                    show = true;
                } else {
                    TextView tv = (TextView) findViewById(R.id.all_text);
                    tv.setText("");
                    allToggle = false;
                    show = false;
                }
            }
        });

        btn.callOnClick();

        fromSpinner = (Spinner) findViewById(R.id.from_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> fromAdapter = ArrayAdapter.createFromResource(this,
                R.array.language_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        fromAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        fromSpinner.setAdapter(fromAdapter);

        toSpinner = (Spinner) findViewById(R.id.to_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> toAdapter = ArrayAdapter.createFromResource(this,
                R.array.language_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        toAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        toSpinner.setAdapter(toAdapter);
    }

    public void chooseCategory() {
        fromSpinner = (Spinner) findViewById(R.id.from_spinner);
        ArrayAdapter<CharSequence> fromAdapter = ArrayAdapter.createFromResource(this,
                R.array.language_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        fromAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        fromSpinner.setAdapter(fromAdapter);
        fromSpinner.setOnItemSelectedListener(new planOnClickListener());
    }

    public void chooseTo() {
        toSpinner = (Spinner) findViewById(R.id.to_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> toAdapter = ArrayAdapter.createFromResource(this,
                R.array.language_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        toAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        toSpinner.setAdapter(toAdapter);
        toSpinner.setOnItemSelectedListener(new languageOnClickListener());
    }

    public void chooseWord() {
        wordSpinner = (Spinner) findViewById(R.id.word_spinner);
        wordSpinner.setOnItemSelectedListener(new wordOnClickListener());
    }

    private void chooseEnglish(){
        englishSpinner = (Spinner) findViewById(R.id.word_spinner);
        List<String> englishList = new ArrayList<String>();
        englishList.add("hello");
        englishList.add("how much?");
        englishList.add("please");
        englishList.add("goodbye");
        englishList.add("thank you");
        ArrayAdapter<String> englishAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, englishList);
        englishAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        englishSpinner.setAdapter(englishAdapter);
    }

    private void chooseChinese(){
        chineseSpinner = (Spinner) findViewById(R.id.word_spinner);
        List<String> chineseList = new ArrayList<String>();
        chineseList.add("你好");
        chineseList.add("多少钱?");
        chineseList.add("请");
        chineseList.add("再见");
        chineseList.add("谢谢");
        ArrayAdapter<String> chineseAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, chineseList);
        chineseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chineseSpinner.setAdapter(chineseAdapter);
    }

    private void chooseSpanish(){
        spanishSpinner = (Spinner) findViewById(R.id.word_spinner);
        List<String> spanishList = new ArrayList<String>();
        spanishList.add("hola");
        spanishList.add("Cuánto?");
        spanishList.add("por favor");
        spanishList.add("adiós");
        spanishList.add("gracias");
        ArrayAdapter<String> spanishAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, spanishList);
        spanishAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spanishSpinner.setAdapter(spanishAdapter);
    }

    public class planOnClickListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
            parent.getItemAtPosition(pos);
            switch (pos) {
                case 0:
                    chooseEnglish();
                    displayTranslatedText();
                    if (show) {
                        displayAll();
                    }
                    break;
                case 1:
                    chooseSpanish();
                    displayTranslatedText();
                    if (show) {
                        displayAll();
                    }
                    break;
                case 2:
                    chooseChinese();
                    displayTranslatedText();
                    if (show) {
                        displayAll();
                    }
                    break;
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
    }

    public class wordOnClickListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
            displayTranslatedText();
            if (show) {
                displayAll();
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
    }

    public class languageOnClickListener implements AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
            displayTranslatedText();
            if (show) {
                displayAll();
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
    }

    public void displayTranslatedText() {
        wordSpinner = (Spinner) findViewById(R.id.word_spinner);
        String message = wordSpinner.getSelectedItem().toString();
        String transMessage = getTranslatedText(message);
        TextView tv = (TextView)findViewById(R.id.result_text);
        tv.setText(transMessage);
    }

    public String getTranslatedText(String message) {
        Spinner spinner1 = (Spinner) findViewById(R.id.from_spinner);
        Spinner spinner2 = (Spinner) findViewById(R.id.to_spinner);
        String fromLanguage = spinner1.getSelectedItem().toString();
        String toLanguage = spinner2.getSelectedItem().toString();

        if (fromLanguage.equals("English")) {
            if (toLanguage.equals("English")) {
                return message;
            } else if (toLanguage.equals("Spanish")) {
                return this.engToSpaMap.get(message);
            } else if (toLanguage.equals("Chinese")) {
                return this.engToMadMap.get(message);
            }

        } else if (fromLanguage.equals("Spanish")) {
            if (toLanguage.equals("English")) {
                return this.spaToEngMap.get(message);
            } else if (toLanguage.equals("Spanish")) {
                return message;
            } else if (toLanguage.equals("Chinese")) {
                return this.spaToMadMap.get(message);
            }

        } else if (fromLanguage.equals("Chinese")) {
            if (toLanguage.equals("English")) {
                return this.madToEngMap.get(message);
            } else if (toLanguage.equals("Spanish")) {
                return this.madToSpaMap.get(message);
            } else if (toLanguage.equals("Chinese")) {
                return message;
            }
        }

        return "Hello";
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_prg01, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /** Called when the user clicks the Send button */
    public void displayAll() {
        TextView tv = (TextView) findViewById(R.id.all_text);
        String message = wordSpinner.getSelectedItem().toString();
        String totalStr = null;
        if (this.engWordMap.contains(message)) {
            totalStr = "Spanish:  " + this.engToSpaMap.get(message) + "\n" + "\n"
                    + "Chinese:  " + this.engToMadMap.get(message);
        } else if (this.spaWordMap.contains(message)) {
            totalStr = "English:  " + this.spaToEngMap.get(message) + "\n" + "\n"
                    + "Chinese:  " + this.spaToMadMap.get(message);
        } else if (this.madWordMap.contains(message)) {
            totalStr = "English:   " + this.madToEngMap.get(message) + "\n" + "\n"
                    + "Spanish:  " + this.madToSpaMap.get(message);
        }
        tv.setText(totalStr);
    }
}
